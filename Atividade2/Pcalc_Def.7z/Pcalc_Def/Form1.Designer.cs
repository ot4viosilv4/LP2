﻿namespace Pcalc_Def
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.title = new System.Windows.Forms.Label();
            this.num1label = new System.Windows.Forms.Label();
            this.num2label = new System.Windows.Forms.Label();
            this.Xtextbox = new System.Windows.Forms.TextBox();
            this.Ytextbox = new System.Windows.Forms.TextBox();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.Closebutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Ztextbox = new System.Windows.Forms.TextBox();
            this.Sumbutton = new System.Windows.Forms.Button();
            this.Subbutton = new System.Windows.Forms.Button();
            this.Tmsbutton = new System.Windows.Forms.Button();
            this.Divbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.title.Location = new System.Drawing.Point(309, 22);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(174, 36);
            this.title.TabIndex = 0;
            this.title.Text = "Calculadora";
            // 
            // num1label
            // 
            this.num1label.AutoSize = true;
            this.num1label.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.num1label.Location = new System.Drawing.Point(78, 92);
            this.num1label.Name = "num1label";
            this.num1label.Size = new System.Drawing.Size(157, 36);
            this.num1label.TabIndex = 1;
            this.num1label.Text = "1° Número";
            // 
            // num2label
            // 
            this.num2label.AutoSize = true;
            this.num2label.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.num2label.Location = new System.Drawing.Point(78, 158);
            this.num2label.Name = "num2label";
            this.num2label.Size = new System.Drawing.Size(157, 36);
            this.num2label.TabIndex = 2;
            this.num2label.Text = "2° Número";
            // 
            // Xtextbox
            // 
            this.Xtextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.Xtextbox.Location = new System.Drawing.Point(257, 92);
            this.Xtextbox.Name = "Xtextbox";
            this.Xtextbox.Size = new System.Drawing.Size(349, 41);
            this.Xtextbox.TabIndex = 3;
            // 
            // Ytextbox
            // 
            this.Ytextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.Ytextbox.Location = new System.Drawing.Point(257, 158);
            this.Ytextbox.Name = "Ytextbox";
            this.Ytextbox.Size = new System.Drawing.Size(349, 41);
            this.Ytextbox.TabIndex = 4;
            // 
            // Clearbutton
            // 
            this.Clearbutton.AutoSize = true;
            this.Clearbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.Clearbutton.Location = new System.Drawing.Point(661, 39);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(101, 49);
            this.Clearbutton.TabIndex = 5;
            this.Clearbutton.Text = "Limpar";
            this.Clearbutton.UseVisualStyleBackColor = true;
            this.Clearbutton.Click += new System.EventHandler(this.Clearbutton_Click);
            // 
            // Closebutton
            // 
            this.Closebutton.AutoSize = true;
            this.Closebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.Closebutton.Location = new System.Drawing.Point(661, 114);
            this.Closebutton.Name = "Closebutton";
            this.Closebutton.Size = new System.Drawing.Size(101, 49);
            this.Closebutton.TabIndex = 6;
            this.Closebutton.Text = "Sair";
            this.Closebutton.UseVisualStyleBackColor = true;
            this.Closebutton.Click += new System.EventHandler(this.Closebutton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label1.Location = new System.Drawing.Point(78, 250);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 36);
            this.label1.TabIndex = 7;
            this.label1.Text = "Resultado";
            // 
            // Ztextbox
            // 
            this.Ztextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.Ztextbox.Location = new System.Drawing.Point(257, 247);
            this.Ztextbox.Name = "Ztextbox";
            this.Ztextbox.ReadOnly = true;
            this.Ztextbox.Size = new System.Drawing.Size(349, 41);
            this.Ztextbox.TabIndex = 8;
            // 
            // Sumbutton
            // 
            this.Sumbutton.AutoSize = true;
            this.Sumbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.Sumbutton.Location = new System.Drawing.Point(101, 329);
            this.Sumbutton.Name = "Sumbutton";
            this.Sumbutton.Size = new System.Drawing.Size(101, 94);
            this.Sumbutton.TabIndex = 9;
            this.Sumbutton.Text = "+";
            this.Sumbutton.UseVisualStyleBackColor = true;
            this.Sumbutton.Click += new System.EventHandler(this.Sumbutton_Click);
            // 
            // Subbutton
            // 
            this.Subbutton.AutoSize = true;
            this.Subbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.Subbutton.Location = new System.Drawing.Point(257, 329);
            this.Subbutton.Name = "Subbutton";
            this.Subbutton.Size = new System.Drawing.Size(101, 94);
            this.Subbutton.TabIndex = 10;
            this.Subbutton.Text = "-";
            this.Subbutton.UseVisualStyleBackColor = true;
            this.Subbutton.Click += new System.EventHandler(this.Subbutton_Click);
            // 
            // Tmsbutton
            // 
            this.Tmsbutton.AutoSize = true;
            this.Tmsbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.Tmsbutton.Location = new System.Drawing.Point(408, 329);
            this.Tmsbutton.Name = "Tmsbutton";
            this.Tmsbutton.Size = new System.Drawing.Size(101, 94);
            this.Tmsbutton.TabIndex = 11;
            this.Tmsbutton.Text = "*";
            this.Tmsbutton.UseVisualStyleBackColor = true;
            this.Tmsbutton.Click += new System.EventHandler(this.Tmsbutton_Click);
            // 
            // Divbutton
            // 
            this.Divbutton.AutoSize = true;
            this.Divbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.Divbutton.Location = new System.Drawing.Point(557, 329);
            this.Divbutton.Name = "Divbutton";
            this.Divbutton.Size = new System.Drawing.Size(101, 94);
            this.Divbutton.TabIndex = 12;
            this.Divbutton.Text = "/";
            this.Divbutton.UseVisualStyleBackColor = true;
            this.Divbutton.Click += new System.EventHandler(this.Divbutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Divbutton);
            this.Controls.Add(this.Tmsbutton);
            this.Controls.Add(this.Subbutton);
            this.Controls.Add(this.Sumbutton);
            this.Controls.Add(this.Ztextbox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Closebutton);
            this.Controls.Add(this.Clearbutton);
            this.Controls.Add(this.Ytextbox);
            this.Controls.Add(this.Xtextbox);
            this.Controls.Add(this.num2label);
            this.Controls.Add(this.num1label);
            this.Controls.Add(this.title);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Label num1label;
        private System.Windows.Forms.Label num2label;
        private System.Windows.Forms.TextBox Xtextbox;
        private System.Windows.Forms.TextBox Ytextbox;
        private System.Windows.Forms.Button Clearbutton;
        private System.Windows.Forms.Button Closebutton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Ztextbox;
        private System.Windows.Forms.Button Subbutton;
        private System.Windows.Forms.Button Tmsbutton;
        private System.Windows.Forms.Button Divbutton;
        private System.Windows.Forms.Button Sumbutton;
    }
}

