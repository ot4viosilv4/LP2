﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc_Def
{
    public partial class Form1 : Form
    {
        double x, y, z;

        private void Clearbutton_Click(object sender, EventArgs e)
        {
            Xtextbox.Clear();
            Ytextbox.Clear();
            Ztextbox.Clear();
        }

        private void Sumbutton_Click(object sender, EventArgs e)
        {
           if (!double.TryParse(Xtextbox.Text, out x))
            {
                MessageBox.Show("Entrada do 1° Número inválida.");
                Focus();
            }
            if (!double.TryParse(Ytextbox.Text, out y))
            {
                MessageBox.Show("Entrada do 2° Número inválida.");
                Focus();
            }
            else
            {
                z = x + y;

                Ztextbox.Text = z.ToString();
            }
        }

        private void Subbutton_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(Xtextbox.Text, out x))
            {
                MessageBox.Show("Entrada do 1° Número inválida.");
                Focus();
            }
            if (!double.TryParse(Ytextbox.Text, out y))
            {
                MessageBox.Show("Entrada do 2° Número inválida.");
                Focus();
            }
            else
            {
                z = x - y;

                Ztextbox.Text = z.ToString();
            }
        }

        private void Tmsbutton_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(Xtextbox.Text, out x))
            {
                MessageBox.Show("Entrada do 1° Número inválida.");
                Focus();
            }
            if (!double.TryParse(Ytextbox.Text, out y))
            {
                MessageBox.Show("Entrada do 2° Número inválida.");
                Focus();
            }
            else
            {
                z = x * y;

                Ztextbox.Text = z.ToString();
            }
        }

        private void Divbutton_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(Xtextbox.Text, out x))
            {
                MessageBox.Show("Entrada do 1° Número inválida.");
                Focus();
            }
            if (!double.TryParse(Ytextbox.Text, out y))
            {
                MessageBox.Show("Entrada do 2° Número inválida.");
                Focus();
            }
            else
            {
                if (y == 0)
                {
                    MessageBox.Show("Impossível divisão por zero.");
                    Focus();
                }
                else
                {
                    z = Math.Round(x / y, 3);

                    Ztextbox.Text = z.ToString();
                }
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Closebutton_Click(object sender, EventArgs e) // Comando para fechar
        {
            Close();
        }
    }
}
