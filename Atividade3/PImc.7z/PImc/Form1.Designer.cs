﻿namespace PImc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelPeso = new System.Windows.Forms.Label();
            this.labelAltura = new System.Windows.Forms.Label();
            this.labelIMC = new System.Windows.Forms.Label();
            this.maskedPeso = new System.Windows.Forms.MaskedTextBox();
            this.maskedAltura = new System.Windows.Forms.MaskedTextBox();
            this.textIMC = new System.Windows.Forms.TextBox();
            this.buttonCalcular = new System.Windows.Forms.Button();
            this.buttonLimpar = new System.Windows.Forms.Button();
            this.buttonSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelPeso
            // 
            this.labelPeso.AutoSize = true;
            this.labelPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.labelPeso.Location = new System.Drawing.Point(26, 26);
            this.labelPeso.Name = "labelPeso";
            this.labelPeso.Size = new System.Drawing.Size(182, 39);
            this.labelPeso.TabIndex = 0;
            this.labelPeso.Text = "Peso Atual";
            // 
            // labelAltura
            // 
            this.labelAltura.AutoSize = true;
            this.labelAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.labelAltura.Location = new System.Drawing.Point(102, 92);
            this.labelAltura.Name = "labelAltura";
            this.labelAltura.Size = new System.Drawing.Size(106, 39);
            this.labelAltura.TabIndex = 1;
            this.labelAltura.Text = "Altura";
            this.labelAltura.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelIMC
            // 
            this.labelIMC.AutoSize = true;
            this.labelIMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.labelIMC.Location = new System.Drawing.Point(128, 156);
            this.labelIMC.Name = "labelIMC";
            this.labelIMC.Size = new System.Drawing.Size(80, 39);
            this.labelIMC.TabIndex = 2;
            this.labelIMC.Text = "IMC";
            this.labelIMC.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // maskedPeso
            // 
            this.maskedPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.maskedPeso.Location = new System.Drawing.Point(223, 30);
            this.maskedPeso.Mask = "900.00";
            this.maskedPeso.Name = "maskedPeso";
            this.maskedPeso.Size = new System.Drawing.Size(275, 36);
            this.maskedPeso.TabIndex = 3;
            // 
            // maskedAltura
            // 
            this.maskedAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.maskedAltura.Location = new System.Drawing.Point(223, 95);
            this.maskedAltura.Mask = "0.00";
            this.maskedAltura.Name = "maskedAltura";
            this.maskedAltura.Size = new System.Drawing.Size(275, 36);
            this.maskedAltura.TabIndex = 4;
            // 
            // textIMC
            // 
            this.textIMC.Enabled = false;
            this.textIMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.textIMC.Location = new System.Drawing.Point(223, 159);
            this.textIMC.Name = "textIMC";
            this.textIMC.Size = new System.Drawing.Size(275, 36);
            this.textIMC.TabIndex = 5;
            // 
            // buttonCalcular
            // 
            this.buttonCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.buttonCalcular.Location = new System.Drawing.Point(48, 221);
            this.buttonCalcular.Name = "buttonCalcular";
            this.buttonCalcular.Size = new System.Drawing.Size(127, 54);
            this.buttonCalcular.TabIndex = 6;
            this.buttonCalcular.Text = "Calcular";
            this.buttonCalcular.UseVisualStyleBackColor = true;
            this.buttonCalcular.Click += new System.EventHandler(this.buttonCalcular_Click);
            // 
            // buttonLimpar
            // 
            this.buttonLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.buttonLimpar.Location = new System.Drawing.Point(201, 221);
            this.buttonLimpar.Name = "buttonLimpar";
            this.buttonLimpar.Size = new System.Drawing.Size(127, 54);
            this.buttonLimpar.TabIndex = 7;
            this.buttonLimpar.Text = "Limpar";
            this.buttonLimpar.UseVisualStyleBackColor = true;
            this.buttonLimpar.Click += new System.EventHandler(this.buttonLimpar_Click);
            // 
            // buttonSair
            // 
            this.buttonSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.buttonSair.Location = new System.Drawing.Point(355, 221);
            this.buttonSair.Name = "buttonSair";
            this.buttonSair.Size = new System.Drawing.Size(127, 54);
            this.buttonSair.TabIndex = 8;
            this.buttonSair.Text = "Sair";
            this.buttonSair.UseVisualStyleBackColor = true;
            this.buttonSair.Click += new System.EventHandler(this.buttonSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(542, 302);
            this.Controls.Add(this.buttonSair);
            this.Controls.Add(this.buttonLimpar);
            this.Controls.Add(this.buttonCalcular);
            this.Controls.Add(this.textIMC);
            this.Controls.Add(this.maskedAltura);
            this.Controls.Add(this.maskedPeso);
            this.Controls.Add(this.labelIMC);
            this.Controls.Add(this.labelAltura);
            this.Controls.Add(this.labelPeso);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelPeso;
        private System.Windows.Forms.Label labelAltura;
        private System.Windows.Forms.Label labelIMC;
        private System.Windows.Forms.MaskedTextBox maskedPeso;
        private System.Windows.Forms.MaskedTextBox maskedAltura;
        private System.Windows.Forms.TextBox textIMC;
        private System.Windows.Forms.Button buttonCalcular;
        private System.Windows.Forms.Button buttonLimpar;
        private System.Windows.Forms.Button buttonSair;
    }
}

