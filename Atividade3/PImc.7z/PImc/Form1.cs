﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        Double p, h, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(maskedPeso.Text, out p))
            {
                MessageBox.Show("Peso Inválido! Tente novamente.");
                maskedPeso.Focus();
            }
            else if (!Double.TryParse(maskedAltura.Text, out h))
            {
                MessageBox.Show("Altura Inválida! Tente novamente.");
                maskedAltura.Focus();
            }
            else if (h == 0)
            {
                MessageBox.Show("Impossível Calcular com Altura 0! Tente novamente.");
                maskedAltura.Focus();
            }
            else
            {
                imc = p / Math.Pow(h, 2);
                imc = Math.Round(imc, 1);

                textIMC.Text = imc.ToString();


                if (imc < 18.5)
                {
                    MessageBox.Show("Classificação: Magreza");
                    Focus();
                }
                else if (imc >= 18.5 && imc <= 24.9)
                {
                    MessageBox.Show("Classificação: Normal");
                    Focus();
                }
                else if (imc > 24.9 && imc <= 29.9)
                {
                    MessageBox.Show("Classificação: Sobrepeso");
                    Focus();
                }
                else if (imc > 29.9 && imc <= 39.9)
                {
                    MessageBox.Show("Classificação: Obesidade");
                }
                else
                {
                    MessageBox.Show("Classificação: Obesidade Grave");
                }
            }
        }

        private void buttonLimpar_Click(object sender, EventArgs e)
        {
            maskedPeso.Clear();
            maskedAltura.Clear();
            textIMC.Clear();

        }


    }
}
