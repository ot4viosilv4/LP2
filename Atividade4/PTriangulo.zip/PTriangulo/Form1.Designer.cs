﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelA = new System.Windows.Forms.Label();
            this.labelB = new System.Windows.Forms.Label();
            this.labelC = new System.Windows.Forms.Label();
            this.buttonExecutar = new System.Windows.Forms.Button();
            this.buttonSair = new System.Windows.Forms.Button();
            this.boxA = new System.Windows.Forms.TextBox();
            this.boxB = new System.Windows.Forms.TextBox();
            this.boxC = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // labelA
            // 
            this.labelA.AutoSize = true;
            this.labelA.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.labelA.Location = new System.Drawing.Point(28, 27);
            this.labelA.Name = "labelA";
            this.labelA.Size = new System.Drawing.Size(176, 39);
            this.labelA.TabIndex = 0;
            this.labelA.Text = "Valor de A";
            // 
            // labelB
            // 
            this.labelB.AutoSize = true;
            this.labelB.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.labelB.Location = new System.Drawing.Point(28, 79);
            this.labelB.Name = "labelB";
            this.labelB.Size = new System.Drawing.Size(176, 39);
            this.labelB.TabIndex = 1;
            this.labelB.Text = "Valor de B";
            // 
            // labelC
            // 
            this.labelC.AutoSize = true;
            this.labelC.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.labelC.Location = new System.Drawing.Point(28, 132);
            this.labelC.Name = "labelC";
            this.labelC.Size = new System.Drawing.Size(178, 39);
            this.labelC.TabIndex = 2;
            this.labelC.Text = "Valor de C";
            // 
            // buttonExecutar
            // 
            this.buttonExecutar.AutoSize = true;
            this.buttonExecutar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.buttonExecutar.Location = new System.Drawing.Point(47, 228);
            this.buttonExecutar.Name = "buttonExecutar";
            this.buttonExecutar.Size = new System.Drawing.Size(144, 107);
            this.buttonExecutar.TabIndex = 3;
            this.buttonExecutar.Text = "Executar";
            this.buttonExecutar.UseVisualStyleBackColor = true;
            this.buttonExecutar.Click += new System.EventHandler(this.buttonExecutar_Click);
            // 
            // buttonSair
            // 
            this.buttonSair.AutoSize = true;
            this.buttonSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.buttonSair.Location = new System.Drawing.Point(229, 228);
            this.buttonSair.Name = "buttonSair";
            this.buttonSair.Size = new System.Drawing.Size(144, 107);
            this.buttonSair.TabIndex = 4;
            this.buttonSair.Text = "Sair";
            this.buttonSair.UseVisualStyleBackColor = true;
            this.buttonSair.Click += new System.EventHandler(this.buttonSair_Click);
            // 
            // boxA
            // 
            this.boxA.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.boxA.Location = new System.Drawing.Point(229, 31);
            this.boxA.Name = "boxA";
            this.boxA.Size = new System.Drawing.Size(169, 36);
            this.boxA.TabIndex = 5;
            // 
            // boxB
            // 
            this.boxB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.boxB.Location = new System.Drawing.Point(229, 82);
            this.boxB.Name = "boxB";
            this.boxB.Size = new System.Drawing.Size(169, 36);
            this.boxB.TabIndex = 6;
            // 
            // boxC
            // 
            this.boxC.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.boxC.Location = new System.Drawing.Point(229, 136);
            this.boxC.Name = "boxC";
            this.boxC.Size = new System.Drawing.Size(169, 36);
            this.boxC.TabIndex = 7;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::PTriangulo.Properties.Resources._93b5cf46e08516529ee840b2c8c7c89f;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(436, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(514, 308);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(971, 369);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.boxC);
            this.Controls.Add(this.boxB);
            this.Controls.Add(this.boxA);
            this.Controls.Add(this.buttonSair);
            this.Controls.Add(this.buttonExecutar);
            this.Controls.Add(this.labelC);
            this.Controls.Add(this.labelB);
            this.Controls.Add(this.labelA);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelA;
        private System.Windows.Forms.Label labelB;
        private System.Windows.Forms.Label labelC;
        private System.Windows.Forms.Button buttonExecutar;
        private System.Windows.Forms.Button buttonSair;
        private System.Windows.Forms.TextBox boxA;
        private System.Windows.Forms.TextBox boxB;
        private System.Windows.Forms.TextBox boxC;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

