﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {

        Double A, B, C;

        private void buttonExecutar_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(boxA.Text, out A) || boxA.Text == "0")
            {
                MessageBox.Show("Entrada Inválida! Tente novamente!");
                boxA.Focus();
            } 
            else if (!Double.TryParse(boxB.Text, out B) || boxB.Text == "0")
            {
                MessageBox.Show("Entrada Inválida! Tente novamente!");
                boxB.Focus();
            } 
            else if (!Double.TryParse(boxC.Text, out C) || boxC.Text == "0")
            {
                MessageBox.Show("Entrada Inválida! Tente novamente.");
                boxC.Focus();
            } else
            {
                if (A + B > C && A + C > B && B + C > A)
                {
                    if (A == B && B == C)
                    {
                        MessageBox.Show("Triângulo é equilátero.");
                    }
                    else if (A == B || A == C || B == C)
                    {
                        MessageBox.Show("Triângulo é isósceles.");
                    }
                    else
                    {
                        MessageBox.Show("Triângulo é escaleno.");
                    }
                }
                else
                {
                    MessageBox.Show("Os valores não pertencem aos lados de um triângulo.");
                }
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
