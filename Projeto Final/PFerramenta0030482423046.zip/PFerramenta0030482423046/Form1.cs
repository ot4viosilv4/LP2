﻿using System;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace PFerramenta0030482423046
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection connectionne;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        private void categoriasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmCategoria>().Count() > 0)
            {
                Application.OpenForms["frmCategoria"].BringToFront();
            }
            else
            {
                frmCategoria FrmCategoria = new frmCategoria();
                FrmCategoria.MdiParent = this;
                FrmCategoria.WindowState = FormWindowState.Maximized;
                FrmCategoria.Show();
            }
        }
        private void fabricantesToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmFabricante>().Count() > 0)
            {
                Application.OpenForms["frmFabricante"].BringToFront();
            }
            else
            {
                frmFabricante FrmFabricante = new frmFabricante();
                FrmFabricante.MdiParent = this;
                FrmFabricante.WindowState = FormWindowState.Maximized;
                FrmFabricante.Show();
            }
        }

        private void ferramentasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmFerramenta>().Count() > 0)
            {
                Application.OpenForms["frmFerramenta"].BringToFront();
            }
            else
            {
                frmFerramenta FrmFerramenta = new frmFerramenta();
                FrmFerramenta.MdiParent = this;
                FrmFerramenta.WindowState = FormWindowState.Maximized;
                FrmFerramenta.Show();
            }
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                connectionne = new SqlConnection("Data Source=LAPTOP-7KALRG0G\\SQLEXPRESS; Initial Catalog = LP2; Integrated Security = True;");
                connectionne.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de Banco de Dados = / " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outro Erro = / " + ex.Message);
            }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmSobre>().Count() > 0)
            {
                Application.OpenForms["frmSobre"].BringToFront();
            }
            else
            {
                frmSobre FrmSobre = new frmSobre();
                FrmSobre.MdiParent = this;
                FrmSobre.WindowState = FormWindowState.Maximized;
                FrmSobre.Show();
            }
        }
    }
}
