﻿using System;
using System.Data;
using System.Windows.Forms;

namespace PFerramenta0030482423046
{
    public partial class frmFerramenta : Form
    {
        private BindingSource bnFerramenta = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsFerramenta = new DataSet();
        private DataSet dsCategoria = new DataSet();
        private DataSet dsFabricante = new DataSet();

        public frmFerramenta()
        {
            InitializeComponent();
        }

        private void frmFerramenta_Load(object sender, EventArgs e)
        {
            try
            {
                Ferramenta RegFerr = new Ferramenta();
                dsFerramenta.Tables.Add(RegFerr.Listar());
                bnFerramenta.DataSource = dsFerramenta.Tables["FERRAMENTA"];
                dgvFerramenta.DataSource = bnFerramenta;
                bnvFerramenta.BindingSource = bnFerramenta;

                txtIdFerramenta.DataBindings.Add("TEXT", bnFerramenta, "id");
                txtNome.DataBindings.Add("TEXT", bnFerramenta, "nome");
                cbxDistribuicao.DataBindings.Add("SelectedItem", bnFerramenta, "distribuicao");
                dtpCadastro.DataBindings.Add("TEXT", bnFerramenta, "dtcadastro");
                txtSiteOficial.DataBindings.Add("TEXT", bnFerramenta, "siteoficial");

                Categoria RegCat = new Categoria();
                dsCategoria.Tables.Add(RegCat.Listar());
                cbxCategoria.DataSource = dsCategoria.Tables["Categoria"];
                cbxCategoria.DisplayMember = "descricao";
                cbxCategoria.ValueMember = "id";
                cbxCategoria.DataBindings.Add("SelectedValue", bnFerramenta, "idCategoria");

                Fabricante RegFab = new Fabricante();
                dsFabricante.Tables.Add(RegFab.Listar());
                cbxFabricante.DataSource = dsFabricante.Tables["Fabricante"];
                cbxFabricante.DisplayMember = "nomefantasia";
                cbxFabricante.ValueMember = "id";
                cbxFabricante.DataBindings.Add("SelectedValue", bnFerramenta, "idFabricante");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnNovoRegistro_Click_1(object sender, EventArgs e)
        {
            if (tbFerramentas.SelectedIndex == 0)
            {
                tbFerramentas.SelectTab(1);
            }

            bnFerramenta.AddNew();
            txtNome.Enabled = true;
            txtNome.Focus();

            txtSiteOficial.Enabled = true;
            cbxDistribuicao.Enabled = true;
            dtpCadastro.Enabled = true;
            cbxCategoria.Enabled = true;
            cbxFabricante.Enabled = true;
            cbxCategoria.SelectedIndex = 0;
            cbxFabricante.SelectedIndex = 0;
            cbxFabricante.SelectedIndex = 0;

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovoRegistro.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;
        }

        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            if (tbFerramentas.SelectedIndex == 0)
            {
                tbFerramentas.SelectTab(1);
            }

            if (MessageBox.Show("Confirmar exclusão?", "Yes or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Ferramenta RegFerr = new Ferramenta();
                RegFerr.IdFerramenta = Convert.ToInt32(txtIdFerramenta.Text);


                if (RegFerr.Excluir() > 0)
                {
                    MessageBox.Show("Fabricante excluída com sucesso!");

                    dsFerramenta.Tables.Clear();
                    dsFerramenta.Tables.Add(RegFerr.Listar());
                    bnFerramenta.DataSource = dsFerramenta.Tables["Ferramenta"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir ferramenta!");
                }
            }
        }

        private void btnAlterar_Click_1(object sender, EventArgs e)
        {
            {
                if (tbFerramentas.SelectedIndex == 0)
                {
                    tbFerramentas.SelectTab(1);
                }

                txtNome.Enabled = true;

                txtSiteOficial.Enabled = true;
                cbxDistribuicao.Enabled = true;
                dtpCadastro.Enabled = true;
                cbxCategoria.Enabled = true;
                cbxFabricante.Enabled = true;

                btnSalvar.Enabled = true;
                btnAlterar.Enabled = false;
                btnNovoRegistro.Enabled = false;
                btnExcluir.Enabled = false;
                btnCancelar.Enabled = true;

                bInclusao = false;
            }
        }

        private void btnSalvar_Click_1(object sender, EventArgs e)
        {
            if (txtNome.Text == "" || (txtNome.Text.Replace(" ", "").Length < 1))
            {
                MessageBox.Show("Nome inválido!");
            }
            else if (cbxDistribuicao.SelectedIndex == -1)
            {
                MessageBox.Show("Distribuição inválida!");
            }
            else if (txtSiteOficial.Text == "" || txtSiteOficial.Text.Replace(" ", "").Length < 8)
            {
                MessageBox.Show("Site oficial inválido!");
            }
            else if (Convert.ToDateTime(dtpCadastro.Value) < DateTime.Today)
            {
                MessageBox.Show("Data inválida!");
            }
            else if (cbxCategoria.SelectedIndex == -1)
            {
                MessageBox.Show("Categoria inválida!");
            }
            else if (cbxFabricante.SelectedIndex == -1)
            {
                MessageBox.Show("Fabricante inválido!");
            }
            else
            {
                Ferramenta RegFerr = new Ferramenta();

                RegFerr.Nome = txtNome.Text;
                RegFerr.Distribuicao = Convert.ToChar(cbxDistribuicao.SelectedItem);
                RegFerr.DtCadastro = dtpCadastro.Value;
                RegFerr.SiteOficial = txtSiteOficial.Text;
                RegFerr.IdCategoria = Convert.ToInt32(cbxCategoria.SelectedValue.ToString());
                RegFerr.IdFabricante = Convert.ToInt32(cbxFabricante.SelectedValue.ToString());

                if (bInclusao)
                {
                    if (RegFerr.Salvar() > 0)
                    {
                        MessageBox.Show("Ferramenta adicionada com sucesso!");

                        txtNome.Enabled = false;

                        txtSiteOficial.Enabled = false;
                        cbxDistribuicao.Enabled = false;
                        dtpCadastro.Enabled = false;
                        cbxCategoria.Enabled = false;
                        cbxFabricante.Enabled = false;

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovoRegistro.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        bInclusao = false;

                        dsFerramenta.Tables.Clear();
                        dsFerramenta.Tables.Add(RegFerr.Listar());
                        bnFerramenta.DataSource = dsFerramenta.Tables["Ferramenta"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao incluir ferramenta!");
                    }
                }
                else
                {
                    RegFerr.IdFerramenta = Convert.ToInt32(txtIdFerramenta.Text);

                    if (RegFerr.Alterar() > 0)
                    {
                        MessageBox.Show("Ferramenta alterada com sucesso!");

                        txtNome.Enabled = false;

                        txtSiteOficial.Enabled = false;
                        cbxDistribuicao.Enabled = false;
                        dtpCadastro.Enabled = false;
                        cbxCategoria.Enabled = false;
                        cbxFabricante.Enabled = false;

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovoRegistro.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        bInclusao = false;

                        dsFerramenta.Tables.Clear();
                        dsFerramenta.Tables.Add(RegFerr.Listar());
                        bnFerramenta.DataSource = dsFerramenta.Tables["Ferramenta"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao alterar ferramenta!");
                    }
                }
            }
        }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {
            bnFerramenta.CancelEdit();

            txtNome.Enabled = false;

            txtSiteOficial.Enabled = false;
            cbxDistribuicao.Enabled = false;
            dtpCadastro.Enabled = false;
            cbxCategoria.Enabled = false;
            cbxFabricante.Enabled = false;

            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovoRegistro.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;

            bInclusao = false;

            
        }

        private void btnSair_Click_1(object sender, EventArgs e)
        {
            Close();
        }
    }
}
