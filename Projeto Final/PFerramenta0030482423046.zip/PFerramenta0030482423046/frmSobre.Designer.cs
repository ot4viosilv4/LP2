﻿namespace PFerramenta0030482423046
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSobre));
            this.labelProjetoFinal = new System.Windows.Forms.Label();
            this.labelIntegrantes = new System.Windows.Forms.Label();
            this.labelNomesIntegrantes = new System.Windows.Forms.Label();
            this.btnHeman = new System.Windows.Forms.Button();
            this.labelProfessora = new System.Windows.Forms.Label();
            this.labelNomeProfessora = new System.Windows.Forms.Label();
            this.pboxLogoFatec = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pboxLogoFatec)).BeginInit();
            this.SuspendLayout();
            // 
            // labelProjetoFinal
            // 
            this.labelProjetoFinal.AutoSize = true;
            this.labelProjetoFinal.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProjetoFinal.Location = new System.Drawing.Point(288, 9);
            this.labelProjetoFinal.Name = "labelProjetoFinal";
            this.labelProjetoFinal.Size = new System.Drawing.Size(207, 23);
            this.labelProjetoFinal.TabIndex = 0;
            this.labelProjetoFinal.Text = "Projeto Final - LP2";
            // 
            // labelIntegrantes
            // 
            this.labelIntegrantes.AutoSize = true;
            this.labelIntegrantes.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIntegrantes.Location = new System.Drawing.Point(33, 69);
            this.labelIntegrantes.Name = "labelIntegrantes";
            this.labelIntegrantes.Size = new System.Drawing.Size(128, 23);
            this.labelIntegrantes.TabIndex = 1;
            this.labelIntegrantes.Text = "Integrantes";
            // 
            // labelNomesIntegrantes
            // 
            this.labelNomesIntegrantes.AutoSize = true;
            this.labelNomesIntegrantes.CausesValidation = false;
            this.labelNomesIntegrantes.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNomesIntegrantes.Location = new System.Drawing.Point(33, 110);
            this.labelNomesIntegrantes.Name = "labelNomesIntegrantes";
            this.labelNomesIntegrantes.Size = new System.Drawing.Size(420, 69);
            this.labelNomesIntegrantes.TabIndex = 2;
            this.labelNomesIntegrantes.Text = "- Otávio Gabriel Neves da Silva\r\n- Guilherme Henrique Moraes de Medeiros\r\n- Nicol" +
    "as Lino Pereira";
            // 
            // btnHeman
            // 
            this.btnHeman.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHeman.BackgroundImage")));
            this.btnHeman.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnHeman.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHeman.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnHeman.Location = new System.Drawing.Point(485, 192);
            this.btnHeman.Name = "btnHeman";
            this.btnHeman.Size = new System.Drawing.Size(286, 210);
            this.btnHeman.TabIndex = 3;
            this.btnHeman.UseVisualStyleBackColor = true;
            this.btnHeman.Click += new System.EventHandler(this.button1_Click);
            // 
            // labelProfessora
            // 
            this.labelProfessora.AutoSize = true;
            this.labelProfessora.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProfessora.Location = new System.Drawing.Point(33, 223);
            this.labelProfessora.Name = "labelProfessora";
            this.labelProfessora.Size = new System.Drawing.Size(120, 23);
            this.labelProfessora.TabIndex = 4;
            this.labelProfessora.Text = "Professora";
            // 
            // labelNomeProfessora
            // 
            this.labelNomeProfessora.AutoSize = true;
            this.labelNomeProfessora.CausesValidation = false;
            this.labelNomeProfessora.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNomeProfessora.Location = new System.Drawing.Point(33, 265);
            this.labelNomeProfessora.Name = "labelNomeProfessora";
            this.labelNomeProfessora.Size = new System.Drawing.Size(365, 23);
            this.labelNomeProfessora.TabIndex = 5;
            this.labelNomeProfessora.Text = "- Denilce de Almeida Oliveira Veloso";
            // 
            // pboxLogoFatec
            // 
            this.pboxLogoFatec.Image = ((System.Drawing.Image)(resources.GetObject("pboxLogoFatec.Image")));
            this.pboxLogoFatec.InitialImage = ((System.Drawing.Image)(resources.GetObject("pboxLogoFatec.InitialImage")));
            this.pboxLogoFatec.Location = new System.Drawing.Point(544, 23);
            this.pboxLogoFatec.Name = "pboxLogoFatec";
            this.pboxLogoFatec.Size = new System.Drawing.Size(227, 117);
            this.pboxLogoFatec.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pboxLogoFatec.TabIndex = 6;
            this.pboxLogoFatec.TabStop = false;
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pboxLogoFatec);
            this.Controls.Add(this.labelNomeProfessora);
            this.Controls.Add(this.labelProfessora);
            this.Controls.Add(this.btnHeman);
            this.Controls.Add(this.labelNomesIntegrantes);
            this.Controls.Add(this.labelIntegrantes);
            this.Controls.Add(this.labelProjetoFinal);
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            ((System.ComponentModel.ISupportInitialize)(this.pboxLogoFatec)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelProjetoFinal;
        private System.Windows.Forms.Label labelIntegrantes;
        private System.Windows.Forms.Label labelNomesIntegrantes;
        private System.Windows.Forms.Button btnHeman;
        private System.Windows.Forms.Label labelProfessora;
        private System.Windows.Forms.Label labelNomeProfessora;
        private System.Windows.Forms.PictureBox pboxLogoFatec;
    }
}